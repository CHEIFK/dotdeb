/**
 * DOT • DEB — Zootopia Mindustry Server Overview
 * Handles live status checking, IP clipboard copy, and theme switching.
 */
(function () {
  "use strict";

  // Elements
  const elStatusPill = document.getElementById("server-status-pill");
  const elStatusText = document.getElementById("server-status-text");
  const elServerAddress = document.getElementById("server-address");
  const elCopyBtn = document.getElementById("copy-ip-btn");
  const elValMap = document.getElementById("val-map");
  const elValWave = document.getElementById("val-wave");
  const elValPlayers = document.getElementById("val-players");
  const elValVersion = document.getElementById("val-version");
  const elLastChecked = document.getElementById("last-checked-time");
  const elRefreshBtn = document.getElementById("refresh-status-btn");
  const elThemeBtn = document.getElementById("theme");

  // Server configuration fallback
  const config = (window.CONFIG && window.CONFIG.mindustry) ? window.CONFIG.mindustry : {
    name: "Zootopia",
    game: "Mindustry",
    ip: "3.26.168.37",
    port: 6567,
    maxPlayersDefault: 16,
    version: "v7 Build 146"
  };

  const apiConfig = (window.CONFIG && window.CONFIG.api) ? window.CONFIG.api : {
    baseUrl: "",
    endpoints: { status: "/api/mindustry/status" },
    timeoutMs: 6000
  };

  const fullAddress = `${config.ip}:${config.port}`;

  // Populate static configuration into UI immediately
  if (elServerAddress) {
    elServerAddress.textContent = fullAddress;
  }
  if (elValVersion) {
    elValVersion.textContent = config.version || "v7 Build 146";
  }

  /**
   * Safe Clipboard Copy
   */
  if (elCopyBtn) {
    elCopyBtn.addEventListener("click", async () => {
      let copied = false;
      if (navigator.clipboard && window.isSecureContext) {
        try {
          await navigator.clipboard.writeText(fullAddress);
          copied = true;
        } catch (err) {
          console.warn("Clipboard API write failed, using fallback:", err);
        }
      }

      if (!copied) {
        // Fallback for non-https or older browser contexts
        const textarea = document.createElement("textarea");
        textarea.value = fullAddress;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        try {
          copied = document.execCommand("copy");
        } catch (err) {
          console.error("ExecCommand copy failed:", err);
        }
        document.body.removeChild(textarea);
      }

      const origText = elCopyBtn.innerHTML;
      if (copied) {
        elCopyBtn.classList.add("copied");
        elCopyBtn.innerHTML = `<span>✓ Copied!</span>`;
      } else {
        elCopyBtn.innerHTML = `<span>Press Ctrl+C</span>`;
      }

      setTimeout(() => {
        elCopyBtn.classList.remove("copied");
        elCopyBtn.innerHTML = origText;
      }, 2200);
    });
  }

  /**
   * Set Status Badge State
   */
  function setStatus(state, message) {
    if (!elStatusPill || !elStatusText) return;

    elStatusPill.classList.remove("status-online", "status-offline", "status-unknown");

    if (state === "online") {
      elStatusPill.classList.add("status-online");
      elStatusText.textContent = "Online";
    } else if (state === "offline") {
      elStatusPill.classList.add("status-offline");
      elStatusText.textContent = "Offline";
    } else {
      // Default to Unknown — never falsely show online or assume offline without confirmation
      elStatusPill.classList.add("status-unknown");
      elStatusText.textContent = "Unknown";
    }

    if (elLastChecked) {
      const now = new Date();
      elLastChecked.textContent = `Last checked: ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}` + (message ? ` (${message})` : "");
    }
  }

  /**
   * Fetch Live Mindustry Status from Backend API
   * If backend is not reached or returns an error, gracefully display 'Unknown'.
   */
  async function checkServerStatus() {
    if (elRefreshBtn) {
      elRefreshBtn.disabled = true;
      elRefreshBtn.textContent = "Checking...";
    }

    const endpoint = (apiConfig.baseUrl || "") + apiConfig.endpoints.status;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), apiConfig.timeoutMs || 6000);

    try {
      const res = await fetch(endpoint, {
        method: "GET",
        headers: { "Accept": "application/json" },
        signal: controller.signal
      });
      clearTimeout(timeout);

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const data = await res.json();

      if (data && data.online === true) {
        setStatus("online");
        if (elValMap) elValMap.textContent = data.map || "Survival";
        if (elValWave) elValWave.textContent = data.wave !== undefined ? data.wave : "—";
        if (elValPlayers) {
          const count = data.players !== undefined ? data.players : 0;
          const max = data.maxPlayers || config.maxPlayersDefault;
          elValPlayers.textContent = `${count} / ${max}`;
        }
      } else if (data && data.online === false) {
        setStatus("offline");
        if (elValMap) elValMap.textContent = "—";
        if (elValWave) elValWave.textContent = "—";
        if (elValPlayers) elValPlayers.textContent = `0 / ${config.maxPlayersDefault}`;
      } else {
        setStatus("unknown", "Invalid response");
        resetToUnknown();
      }
    } catch (err) {
      // Graceful fallback: Network error, offline backend, or timeout
      // NEVER claim server is online when API is unavailable.
      setStatus("unknown", "API unavailable");
      resetToUnknown();
    } finally {
      if (elRefreshBtn) {
        elRefreshBtn.disabled = false;
        elRefreshBtn.textContent = "↻ Refresh Status";
      }
    }
  }

  function resetToUnknown() {
    if (elValMap) elValMap.textContent = "Unknown";
    if (elValWave) elValWave.textContent = "—";
    if (elValPlayers) elValPlayers.textContent = `— / ${config.maxPlayersDefault}`;
  }

  if (elRefreshBtn) {
    elRefreshBtn.addEventListener("click", checkServerStatus);
  }

  // Theme Toggle Support (matches index.html behavior and persistent localStorage)
  if (elThemeBtn) {
    elThemeBtn.addEventListener("click", () => {
      document.body.classList.toggle("dark");
      localStorage.setItem("theme", document.body.classList.contains("dark") ? "dark" : "light");
    });
  }

  if (localStorage.getItem("theme") === "dark") {
    document.body.classList.add("dark");
  }

  // Set Year in footer if present
  const yearEl = document.getElementById("year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // Initial check on page load
  checkServerStatus();
})();
