/**
 * DOT • DEB — Global Site & Server Configuration
 * Centralized settings for Zootopia Mindustry Server and backend integrations.
 *
 * NOTE: The AWS EC2 IP may change if the instance is stopped and restarted without an Elastic IP.
 * Keep all server connection details here so you only ever have to update them in one place.
 */
const CONFIG = {
  // Public Mindustry Server Connection Details
  mindustry: {
    name: "Zootopia",
    game: "Mindustry",
    ip: "3.26.168.37",
    port: 6567,
    protocol: "TCP/UDP",
    defaultMap: "Unknown",
    maxPlayersDefault: 16,
    version: "v7 Build 146"
  },

  // Backend Management API Configuration
  // Replace baseUrl with your production backend domain (e.g. "https://api.dotdeb.dpdns.org")
  api: {
    baseUrl: (typeof window !== "undefined" && window.__API_BASE_URL__) || "",
    endpoints: {
      status: "/api/mindustry/status",
      metrics: "/api/mindustry/metrics",
      auth: {
        login: "/api/auth/login",
        logout: "/api/auth/logout",
        session: "/api/auth/session"
      },
      controls: {
        start: "/api/mindustry/control/start",
        stop: "/api/mindustry/control/stop",
        restart: "/api/mindustry/control/restart"
      },
      config: "/api/mindustry/config",
      players: "/api/mindustry/players",
      playerAction: "/api/mindustry/players/action",
      logs: "/api/mindustry/logs",
      console: "/api/mindustry/console"
    },
    timeoutMs: 6000,
    pollIntervalMs: 15000
  }
};

// Freeze configuration to prevent accidental modification
if (typeof Object.freeze === "function") {
  Object.freeze(CONFIG);
  Object.freeze(CONFIG.mindustry);
  Object.freeze(CONFIG.api);
  Object.freeze(CONFIG.api.endpoints);
  Object.freeze(CONFIG.api.endpoints.auth);
  Object.freeze(CONFIG.api.endpoints.controls);
}

if (typeof window !== "undefined") {
  window.CONFIG = CONFIG;
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = CONFIG;
}
