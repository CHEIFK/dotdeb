#!/usr/bin/env python3
"""
DOT • DEB — Local Development Server
Serves static frontend assets and provides a local mock API for testing the
Zootopia Mindustry server overview and admin dashboard.

Usage:
    python3 server.py [PORT]
    (Default port: 8080)
"""

import sys
import os
import json
import http.server
import socketserver
from http import cookies

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8080

# In-memory mock server state for local testing
SERVER_STATE = {
    "online": True,
    "name": "Zootopia",
    "map": "Tar Fields",
    "wave": 24,
    "players": 3,
    "maxPlayers": 16,
    "motd": "A multiplayer Mindustry world. Build, survive, and play together.",
    "uptime": "2d 18h 42m",
    "cpu": 18.4,
    "ram": 512,
    "ramTotal": 2048,
    "version": "v7 Build 146"
}

MOCK_PLAYERS = [
    {"id": "p-101", "name": "RogueMiner", "ping": 38, "duration": "1h 24m"},
    {"id": "p-102", "name": "CoreBuilder", "ping": 64, "duration": "48m"},
    {"id": "p-103", "name": "SectorScout", "ping": 27, "duration": "15m"}
]

class LocalDevHandler(http.server.SimpleHTTPRequestHandler):
    def send_json(self, data, status_code=200, headers=None):
        payload = json.dumps(data).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        if headers:
            for k, v in headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(payload)

    def get_cookie(self, name):
        cookie_header = self.headers.get("Cookie")
        if not cookie_header:
            return None
        c = cookies.SimpleCookie()
        c.load(cookie_header)
        return c[name].value if name in c else None

    def read_json_body(self):
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            if content_length > 0:
                raw = self.rfile.read(content_length)
                return json.loads(raw.decode("utf-8"))
        except Exception:
            pass
        return {}

    def do_GET(self):
        path = self.path.split("?")[0]

        # Public Status Endpoint
        if path == "/api/mindustry/status":
            return self.send_json({
                "online": SERVER_STATE["online"],
                "map": SERVER_STATE["map"] if SERVER_STATE["online"] else "—",
                "wave": SERVER_STATE["wave"] if SERVER_STATE["online"] else 0,
                "players": len(MOCK_PLAYERS) if SERVER_STATE["online"] else 0,
                "maxPlayers": SERVER_STATE["maxPlayers"],
                "uptime": SERVER_STATE["uptime"],
                "cpu": SERVER_STATE["cpu"],
                "ram": SERVER_STATE["ram"]
            })

        # Server Metrics Endpoint
        if path == "/api/mindustry/metrics":
            return self.send_json({
                "online": SERVER_STATE["online"],
                "cpu": SERVER_STATE["cpu"],
                "ram": SERVER_STATE["ram"],
                "ramTotal": SERVER_STATE["ramTotal"],
                "uptime": SERVER_STATE["uptime"]
            })

        # Session Verification Endpoint
        if path == "/api/auth/session":
            session_token = self.get_cookie("admin_session")
            is_authenticated = bool(session_token and session_token.startswith("dev_session_"))
            return self.send_json({
                "ok": True,
                "authenticated": is_authenticated,
                "user": "admin" if is_authenticated else None
            })

        # Players List Endpoint
        if path == "/api/mindustry/players":
            return self.send_json(MOCK_PLAYERS if SERVER_STATE["online"] else [])

        # Default static file serving
        return super().do_GET()

    def do_POST(self):
        path = self.path.split("?")[0]
        body = self.read_json_body()

        # Admin Login Endpoint
        if path == "/api/auth/login":
            username = body.get("username", "")
            password = body.get("password", "")

            # Test credentials: admin / admin (or admin / mindustry)
            if username == "admin" and password in ["admin", "mindustry", "password"]:
                return self.send_json(
                    {"ok": True, "message": "Authenticated"},
                    status_code=200,
                    headers={"Set-Cookie": "admin_session=dev_session_active; Path=/; SameSite=Lax; HttpOnly"}
                )
            else:
                return self.send_json(
                    {"ok": False, "error": "Invalid username or password. (Local test: admin / admin)"},
                    status_code=401
                )

        # Admin Logout Endpoint
        if path == "/api/auth/logout":
            return self.send_json(
                {"ok": True, "message": "Signed out"},
                status_code=200,
                headers={"Set-Cookie": "admin_session=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT"}
            )

        # Server Lifecycle Controls
        if path.startswith("/api/mindustry/control/"):
            action = path.split("/")[-1]
            if action == "start":
                SERVER_STATE["online"] = True
                return self.send_json({"ok": True, "action": "start", "message": "Mindustry server started."})
            elif action == "stop":
                SERVER_STATE["online"] = False
                return self.send_json({"ok": True, "action": "stop", "message": "Mindustry server stopped."})
            elif action == "restart":
                SERVER_STATE["online"] = True
                return self.send_json({"ok": True, "action": "restart", "message": "Mindustry server restarted."})
            else:
                return self.send_json({"ok": False, "error": f"Unknown action: {action}"}, status_code=400)

        # Configuration Update
        if path == "/api/mindustry/config":
            if "name" in body: SERVER_STATE["name"] = str(body["name"])
            if "playerLimit" in body: SERVER_STATE["maxPlayers"] = int(body["playerLimit"])
            if "map" in body: SERVER_STATE["map"] = str(body["map"])
            if "motd" in body: SERVER_STATE["motd"] = str(body["motd"])
            return self.send_json({"ok": True, "message": "Configuration saved successfully."})

        # Player Action (Kick / Ban / Unban)
        if path == "/api/mindustry/players/action":
            action = body.get("action")
            player_id = body.get("playerId")
            if action in ["kick", "ban"]:
                global MOCK_PLAYERS
                MOCK_PLAYERS = [p for p in MOCK_PLAYERS if p["id"] != player_id]
                return self.send_json({"ok": True, "message": f"Player {player_id} {action}ed."})
            elif action == "unban":
                return self.send_json({"ok": True, "message": f"Player {player_id} unbanned."})
            return self.send_json({"ok": False, "error": "Invalid player action"}, status_code=400)

        # Console Command Execution
        if path == "/api/mindustry/console":
            cmd = body.get("command", "").strip()
            parts = cmd.split()
            root = parts[0].lower() if parts else ""

            if root == "help":
                out = "Available commands: status, say <message>, pause, resume, waves <count>, nextmap, reloadmaps, gameover, version"
            elif root == "status":
                out = f"Server: {SERVER_STATE['name']} | Map: {SERVER_STATE['map']} | Wave: {SERVER_STATE['wave']} | Players: {len(MOCK_PLAYERS)}/{SERVER_STATE['maxPlayers']} | FPS: 60"
            elif root == "say":
                msg = " ".join(parts[1:]) if len(parts) > 1 else ""
                out = f"[Broadcast] Admin: {msg}"
            elif root == "pause":
                out = "Game paused."
            elif root == "resume":
                out = "Game unpaused."
            elif root == "waves":
                count = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 1
                SERVER_STATE["wave"] += count
                out = f"Skipped {count} wave(s). Now on wave {SERVER_STATE['wave']}."
            elif root == "nextmap":
                SERVER_STATE["map"] = "Impact 0078"
                SERVER_STATE["wave"] = 1
                out = f"Switched to next map: {SERVER_STATE['map']}"
            elif root == "reloadmaps":
                out = "Maps reloaded successfully (14 maps loaded)."
            elif root == "gameover":
                out = "Game over triggered. Core destroyed."
            elif root == "version":
                out = f"Mindustry Server Build: {SERVER_STATE['version']}"
            else:
                out = f"Executed Mindustry command: {cmd}"

            return self.send_json({"ok": True, "output": out})

        return self.send_json({"ok": False, "error": "Not Found"}, status_code=404)

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), LocalDevHandler) as httpd:
        print(f"==================================================")
        print(f" DOT • DEB Local Server running at:")
        print(f" -> http://localhost:{PORT}")
        print(f" -> http://127.0.0.1:{PORT}")
        print(f"")
        print(f" Pages:")
        print(f" - Homepage:  http://localhost:{PORT}/index.html")
        print(f" - Zootopia:  http://localhost:{PORT}/zootopia.html")
        print(f" - Login:     http://localhost:{PORT}/admin/login.html")
        print(f" - Dashboard: http://localhost:{PORT}/admin/dashboard.html")
        print(f"")
        print(f" Test Admin Credentials: admin / admin")
        print(f"==================================================")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down local server.")
