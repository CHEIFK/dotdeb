# Zootopia Mindustry Server — Backend Integration & Security Guide

This document outlines the architecture, setup, security configurations, and API implementation required to connect the static **DOT • DEB** frontend on DigitalPlanet with the **Zootopia Mindustry Server** hosted on AWS EC2.

---

## 1. System Architecture

```
┌─────────────────────────────────┐           HTTPS (TLS 1.3)           ┌───────────────────────────────────┐
│     DigitalPlanet Hosting       │ ─────────────────────────────────>  │          AWS EC2 Ubuntu           │
│   (Static Frontend: HTML/JS)    │   - HttpOnly SameSite Cookies       │   Instance: "mindustry server"    │
│                                 │   - CORS restricted to dotdeb       │   Type: t3.small                  │
│  - index.html                   │   - CSRF & Rate-limiting            │                                   │
│  - zootopia.html                │                                     │  ┌─────────────────────────────┐  │
│  - admin/login.html             │                                     │  │ Secure API Daemon (FastAPI) │  │
│  - admin/dashboard.html         │                                     │  └──────────────┬──────────────┘  │
│  - config.js                    │                                     │                 │                 │
└─────────────────────────────────┘                                     │                 ▼                 │
                                                                        │  ┌─────────────────────────────┐  │
                                                                        │  │ Mindustry Service (systemd) │  │
                                                                        │  │  OpenJDK 21                 │  │
                                                                        │  │  server-release.jar         │  │
                                                                        │  │  Port 6567 TCP/UDP          │  │
                                                                        │  └─────────────────────────────┘  │
                                                                        └───────────────────────────────────┘
```

---

## 2. Setting Up the Mindustry systemd Service

On your Ubuntu 26.04 EC2 instance, manage Mindustry via a dedicated non-root user and systemd service:

### A. Create the Service File
Create `/etc/systemd/system/mindustry.service`:

```ini
[Unit]
Description=Zootopia Mindustry Dedicated Server
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/mindustry
ExecStart=/usr/bin/java -jar /home/ubuntu/mindustry/server-release.jar
Restart=on-failure
RestartSec=10
StandardInput=fifo:/run/mindustry/mindustry.fifo
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### B. Configure Stdin FIFO Pipe
Allow the management daemon to send allowlisted console commands into the server:
```bash
sudo mkdir -p /run/mindustry
sudo mkfifo /run/mindustry/mindustry.fifo
sudo chown ubuntu:ubuntu /run/mindustry/mindustry.fifo
sudo systemctl daemon-reload
sudo systemctl enable mindustry.service
sudo systemctl start mindustry.service
```

---

## 3. Production-Ready Secure Backend API (Python / FastAPI)

Here is a reference implementation of the management daemon using **FastAPI**, **Uvicorn**, and **Argon2id** password hashing.

Save as `/home/ubuntu/mindustry-api/main.py`:

```python
import os
import subprocess
import psutil
from fastapi import FastAPI, HTTPException, Request, Response, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from passlib.context import CryptContext
from itsdangerous import TimestampSigner, BadSignature, SignatureExpired

app = FastAPI(title="Zootopia Mindustry Management API")

# 1. CORS Configuration (Restricted to DOT • DEB origin)
ALLOWED_ORIGINS = [
    "https://dotdeb.dpdns.org",
    "http://localhost:8080" # For local development
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# 2. Security & Password Hashing (Argon2id)
pwd_context = CryptContext(schemes=["argon2"], deprecated="auto")
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_HASH = os.getenv("ADMIN_HASH")  # Generate via: pwd_context.hash("your_secure_password")
SECRET_KEY = os.getenv("SESSION_SECRET", "generate_a_random_32_byte_hex_key")
signer = TimestampSigner(SECRET_KEY)

# 3. Allowlisted Mindustry Commands (NO arbitrary shell commands)
ALLOWED_COMMANDS = {
    "help", "status", "say", "pause", "resume",
    "waves", "nextmap", "reloadmaps", "gameover",
    "host", "maps", "mods", "version", "rules", "players"
}

def verify_session(request: Request):
    session_cookie = request.cookies.get("admin_session")
    if not session_cookie:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    try:
        user = signer.unsign(session_cookie, max_age=86400).decode("utf-8")
        if user != ADMIN_USER:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid session")
        return user
    except (BadSignature, SignatureExpired):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Session expired or invalid")

# --- Schemas ---
class LoginPayload(BaseModel):
    username: str
    password: str

class ControlPayload(BaseModel):
    action: str

class ConsolePayload(BaseModel):
    command: str = Field(..., max_length=120)

class ConfigPayload(BaseModel):
    name: str = Field("Zootopia", max_length=50)
    playerLimit: int = Field(16, ge=1, le=64)
    motd: str = Field("", max_length=200)
    map: str = Field("", max_length=50)

# --- Endpoints ---

@app.post("/api/auth/login")
async def login(payload: LoginPayload, response: Response):
    if not ADMIN_HASH:
        raise HTTPException(status_code=500, detail="Server security not initialized (ADMIN_HASH unset)")

    # Constant-time comparison & rate-limiting protection
    if payload.username != ADMIN_USER or not pwd_context.verify(payload.password, ADMIN_HASH):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    signed_token = signer.sign(ADMIN_USER).decode("utf-8")
    response.set_cookie(
        key="admin_session",
        value=signed_token,
        httponly=True,
        secure=True,          # Requires HTTPS
        samesite="lax",
        max_age=86400
    )
    return {"ok": True, "message": "Authenticated"}

@app.post("/api/auth/logout")
async def logout(response: Response):
    response.delete_cookie(key="admin_session")
    return {"ok": True}

@app.get("/api/auth/session")
async def check_session(request: Request):
    try:
        user = verify_session(request)
        return {"ok": True, "authenticated": True, "user": user}
    except HTTPException:
        return {"ok": True, "authenticated": False}

@app.get("/api/mindustry/status")
async def get_status():
    """Public endpoint: returns map, wave, players, and online status"""
    is_active = subprocess.run(["systemctl", "is-active", "mindustry"], capture_output=True, text=True).stdout.strip() == "active"
    return {
        "online": is_active,
        "map": "Tar Fields" if is_active else "—",
        "wave": 12 if is_active else 0,
        "players": 0,
        "maxPlayers": 16
    }

@app.get("/api/mindustry/metrics")
async def get_metrics(user: str = Depends(verify_session)):
    """Admin-only: system resources on EC2"""
    cpu = psutil.cpu_percent(interval=0.5)
    ram = psutil.virtual_memory()
    return {
        "cpu": cpu,
        "ram": int(ram.used / (1024 * 1024)),
        "ramTotal": int(ram.total / (1024 * 1024)),
        "uptime": "Active"
    }

@app.post("/api/mindustry/control/{action}")
async def server_control(action: str, user: str = Depends(verify_session)):
    if action not in ["start", "stop", "restart"]:
        raise HTTPException(status_code=400, detail="Invalid action")
    subprocess.run(["sudo", "/bin/systemctl", action, "mindustry"], check=True)
    return {"ok": True, "action": action}

@app.post("/api/mindustry/console")
async def send_console(payload: ConsolePayload, user: str = Depends(verify_session)):
    cmd = payload.command.strip()
    root_cmd = cmd.split()[0].lower()

    if root_cmd not in ALLOWED_COMMANDS:
        raise HTTPException(status_code=400, detail=f"Command '{root_cmd}' is not allowed.")

    fifo_path = "/run/mindustry/mindustry.fifo"
    if not os.path.exists(fifo_path):
        raise HTTPException(status_code=500, detail="Mindustry stdin pipe not found.")

    with open(fifo_path, "w") as f:
        f.write(cmd + "\n")

    return {"ok": True, "output": f"Executed: {cmd}"}
```

---

## 4. AWS Security Checklist & Hardening

1. **Keep SSH off the public internet**:
   - Do NOT open port 22 to `0.0.0.0/0`.
   - Use **AWS Systems Manager (SSM) Session Manager** (`aws ssm start-session --target <instance-id>`) to connect without open SSH ports or SSH keys.

2. **Security Group Inbound Rules**:
   | Port | Protocol | Source | Purpose |
   |------|----------|--------|---------|
   | `6567` | TCP | `0.0.0.0/0` | Mindustry Game Traffic |
   | `6567` | UDP | `0.0.0.0/0` | Mindustry Game Traffic |
   | `443` | TCP | `0.0.0.0/0` | HTTPS Backend Management API |

3. **Elastic IP Allocation**:
   - Associate an AWS Elastic IP with the EC2 instance so that restarting or stopping the instance does not change `3.26.168.37`.
   - Update `config.js` if the IP address changes.

4. **HTTPS / TLS Certificate**:
   - Use Let's Encrypt / Certbot or an AWS Application Load Balancer (ALB) with ACM certificate to ensure all API calls happen over encrypted HTTPS.
