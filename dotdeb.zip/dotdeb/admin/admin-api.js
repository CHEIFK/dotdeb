/**
 * DOT • DEB — Admin API Client
 *
 * Architecture & Security Guidelines:
 * 1. DigitalPlanet hosts purely static frontend assets. This client connects to a separate,
 *    secure backend over HTTPS (e.g. AWS API Gateway, reverse proxy, or EC2 service).
 * 2. Sessions rely on secure, HttpOnly, SameSite=Strict cookies set by the backend.
 *    No tokens or passwords are ever saved in localStorage or sessionStorage.
 * 3. All server actions (start, stop, restart, config, kick, ban) and console commands are
 *    strictly validated and authorized by the backend against an allowlist.
 * 4. When the backend is disconnected, this layer returns explicit status indicators
 *    so the UI never gives false impressions of live controls.
 */
(function (global) {
  "use strict";

  // Strict list of safe Mindustry server console commands
  const ALLOWED_COMMANDS = new Set([
    "help",
    "status",
    "say",
    "pause",
    "resume",
    "waves",
    "nextmap",
    "reloadmaps",
    "gameover",
    "host",
    "maps",
    "mods",
    "version",
    "rules",
    "players"
  ]);

  // Forbidden shell/injection patterns
  const SHELL_METACHARS = /[;&|`$><\\!]/;

  const AdminAPI = {
    /**
     * Resolves the full URL for an endpoint
     */
    _url(path) {
      const base = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.baseUrl) || "";
      return base + path;
    },

    /**
     * Core Fetch wrapper with timeout, credentials, and error handling
     */
    async _request(endpoint, options = {}) {
      const timeoutMs = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.timeoutMs) || 6000;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);

      const defaultHeaders = {
        "Accept": "application/json"
      };

      if (options.body && typeof options.body === "object") {
        defaultHeaders["Content-Type"] = "application/json";
        options.body = JSON.stringify(options.body);
      }

      // Check for CSRF token cookie if present
      const csrfToken = this._getCookie("csrf_token") || this._getCookie("XSRF-TOKEN");
      if (csrfToken) {
        defaultHeaders["X-CSRF-Token"] = csrfToken;
      }

      const fetchOptions = {
        ...options,
        headers: { ...defaultHeaders, ...(options.headers || {}) },
        credentials: "include", // Ensures HttpOnly cookies are transmitted
        signal: controller.signal
      };

      try {
        const response = await fetch(this._url(endpoint), fetchOptions);
        clearTimeout(timer);

        const contentType = response.headers.get("content-type") || "";
        const isJson = contentType.includes("application/json");
        const data = isJson ? await response.json() : await response.text();

        if (!response.ok) {
          const errMsg = (data && data.message) || (data && data.error) || `Server returned HTTP ${response.status}`;
          return {
            ok: false,
            status: response.status,
            error: errMsg,
            data
          };
        }

        return {
          ok: true,
          status: response.status,
          data
        };
      } catch (err) {
        clearTimeout(timer);
        const isTimeout = err.name === "AbortError";
        return {
          ok: false,
          status: 0,
          error: isTimeout
            ? "Request timed out. The backend server did not respond in time."
            : "Network error: Secure backend is currently unreachable. Ensure your API service is running with valid HTTPS certificates.",
          isNetworkError: true
        };
      }
    },

    _getCookie(name) {
      if (typeof document === "undefined") return null;
      const matches = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, "\\$1") + "=([^;]*)"));
      return matches ? decodeURIComponent(matches[1]) : null;
    },

    /**
     * Authenticate Administrator
     * POST /api/auth/login
     */
    async login(username, password) {
      if (!username || !password) {
        return { ok: false, error: "Please enter both username and password." };
      }

      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      const loginUrl = (endpoints.auth && endpoints.auth.login) || "/api/auth/login";

      return await this._request(loginUrl, {
        method: "POST",
        body: { username, password }
      });
    },

    /**
     * Terminate Session
     * POST /api/auth/logout
     */
    async logout() {
      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      const logoutUrl = (endpoints.auth && endpoints.auth.logout) || "/api/auth/logout";

      return await this._request(logoutUrl, {
        method: "POST"
      });
    },

    /**
     * Check Session Validity
     * GET /api/auth/session
     */
    async checkSession() {
      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      const sessionUrl = (endpoints.auth && endpoints.auth.session) || "/api/auth/session";

      return await this._request(sessionUrl, {
        method: "GET"
      });
    },

    /**
     * Get Server Status & Metrics
     */
    async getStatus() {
      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      return await this._request(endpoints.status || "/api/mindustry/status", { method: "GET" });
    },

    async getMetrics() {
      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      return await this._request(endpoints.metrics || "/api/mindustry/metrics", { method: "GET" });
    },

    /**
     * Server Power Controls (Start / Stop / Restart)
     */
    async controlServer(action) {
      const validActions = ["start", "stop", "restart"];
      if (!validActions.includes(action)) {
        return { ok: false, error: `Invalid control action: ${action}` };
      }

      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      const targetUrl = (endpoints.controls && endpoints.controls[action]) || `/api/mindustry/control/${action}`;

      return await this._request(targetUrl, {
        method: "POST",
        body: { action, timestamp: Date.now() }
      });
    },

    /**
     * Update Server Configuration
     */
    async updateConfig(configData) {
      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      return await this._request(endpoints.config || "/api/mindustry/config", {
        method: "POST",
        body: configData
      });
    },

    /**
     * Player Management
     */
    async getPlayers() {
      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      return await this._request(endpoints.players || "/api/mindustry/players", { method: "GET" });
    },

    async playerAction(action, playerId, reason = "") {
      const validActions = ["kick", "ban", "unban"];
      if (!validActions.includes(action)) {
        return { ok: false, error: `Invalid player action: ${action}` };
      }

      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      return await this._request(endpoints.playerAction || "/api/mindustry/players/action", {
        method: "POST",
        body: { action, playerId, reason }
      });
    },

    /**
     * Server Console & Logs
     */
    async getLogs() {
      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      return await this._request(endpoints.logs || "/api/mindustry/logs", { method: "GET" });
    },

    /**
     * Execute Allowlisted Mindustry Console Command
     * Strictly blocks shell injections or unapproved commands
     */
    async sendConsoleCommand(rawInput) {
      const trimmed = (rawInput || "").trim();
      if (!trimmed) {
        return { ok: false, error: "Command cannot be empty." };
      }

      // Check for dangerous shell characters
      if (SHELL_METACHARS.test(trimmed)) {
        return {
          ok: false,
          error: "Security violation: Shell metacharacters (; & | ` $ > <) are strictly disallowed."
        };
      }

      // Extract command root
      const parts = trimmed.split(/\s+/);
      const rootCommand = parts[0].toLowerCase();

      if (!ALLOWED_COMMANDS.has(rootCommand)) {
        return {
          ok: false,
          error: `Disallowed command "${rootCommand}". Permitted commands: ${Array.from(ALLOWED_COMMANDS).join(", ")}`
        };
      }

      const endpoints = (window.CONFIG && window.CONFIG.api && window.CONFIG.api.endpoints) || {};
      return await this._request(endpoints.console || "/api/mindustry/console", {
        method: "POST",
        body: { command: trimmed }
      });
    }
  };

  global.AdminAPI = AdminAPI;
})(typeof window !== "undefined" ? window : this);
