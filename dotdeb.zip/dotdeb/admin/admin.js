/**
 * DOT • DEB — Admin Dashboard Logic
 * Coordinates UI tabs, server controls, safe console execution, player management, and API sync.
 */
(function () {
  "use strict";

  // Elements
  const tabButtons = document.querySelectorAll(".tab-btn");
  const tabPanels = document.querySelectorAll(".tab-panel");
  const signOutBtn = document.getElementById("btn-signout");
  const themeBtn = document.getElementById("theme");
  const toastEl = document.getElementById("admin-toast");

  // Overview Elements
  const statusBadge = document.getElementById("dash-status-pill");
  const statusText = document.getElementById("dash-status-text");
  const uptimeVal = document.getElementById("dash-uptime");
  const mapVal = document.getElementById("dash-map");
  const waveVal = document.getElementById("dash-wave");
  const playersVal = document.getElementById("dash-players");
  const cpuVal = document.getElementById("dash-cpu");
  const ramVal = document.getElementById("dash-ram");
  const refreshDashBtn = document.getElementById("dash-refresh-btn");
  const backendNotice = document.getElementById("backend-notice");

  // Control Elements
  const btnStart = document.getElementById("ctrl-start");
  const btnStop = document.getElementById("ctrl-stop");
  const btnRestart = document.getElementById("ctrl-restart");

  // Modal Elements
  const modalOverlay = document.getElementById("confirm-modal");
  const modalTitle = document.getElementById("modal-title");
  const modalDesc = document.getElementById("modal-desc");
  const modalConfirmBtn = document.getElementById("modal-btn-confirm");
  const modalCancelBtn = document.getElementById("modal-btn-cancel");
  let pendingActionCallback = null;

  // Config Form Elements
  const configForm = document.getElementById("server-config-form");
  const inputServerName = document.getElementById("cfg-server-name");
  const inputPlayerLimit = document.getElementById("cfg-player-limit");
  const inputMotd = document.getElementById("cfg-motd");
  const inputMap = document.getElementById("cfg-map");

  // Player Elements
  const playerTableBody = document.getElementById("players-table-body");
  const btnUnban = document.getElementById("btn-unban-action");
  const inputUnbanId = document.getElementById("unban-player-id");

  // Console Elements
  const consoleOutput = document.getElementById("console-output");
  const consoleInput = document.getElementById("console-input");
  const consoleSubmitBtn = document.getElementById("console-send-btn");
  const autoScrollToggle = document.getElementById("console-autoscroll");
  const clearConsoleBtn = document.getElementById("console-clear-btn");
  const commandChips = document.querySelectorAll(".chip-btn");

  /**
   * Toast notification helper
   */
  function showToast(message, duration = 3000) {
    if (!toastEl) return;
    toastEl.textContent = message;
    toastEl.classList.add("show");
    setTimeout(() => {
      toastEl.classList.remove("show");
    }, duration);
  }

  /**
   * Confirmation Modal Helper
   */
  function askConfirmation(title, message, confirmLabel, confirmClass, onConfirm) {
    if (!modalOverlay) return;
    modalTitle.textContent = title;
    modalDesc.textContent = message;
    modalConfirmBtn.textContent = confirmLabel || "Confirm";
    modalConfirmBtn.className = `btn-ctrl ${confirmClass || ""}`;
    pendingActionCallback = onConfirm;
    modalOverlay.classList.add("open");
  }

  function closeModal() {
    if (!modalOverlay) return;
    modalOverlay.classList.remove("open");
    pendingActionCallback = null;
  }

  if (modalCancelBtn) modalCancelBtn.addEventListener("click", closeModal);
  if (modalOverlay) {
    modalOverlay.addEventListener("click", (e) => {
      if (e.target === modalOverlay) closeModal();
    });
  }
  if (modalConfirmBtn) {
    modalConfirmBtn.addEventListener("click", () => {
      if (typeof pendingActionCallback === "function") {
        pendingActionCallback();
      }
      closeModal();
    });
  }

  /**
   * Tab Navigation
   */
  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.tab;
      tabButtons.forEach((b) => b.classList.remove("active"));
      tabPanels.forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      const panel = document.getElementById(`panel-${target}`);
      if (panel) panel.classList.add("active");
    });
  });

  /**
   * Append Line to Console Window
   */
  function appendConsoleLine(text, type = "info") {
    if (!consoleOutput) return;
    const line = document.createElement("div");
    line.className = `console-line ${type}`;
    const timestamp = new Date().toLocaleTimeString();
    line.textContent = `[${timestamp}] ${text}`;
    consoleOutput.appendChild(line);

    if (autoScrollToggle && autoScrollToggle.checked) {
      consoleOutput.scrollTop = consoleOutput.scrollHeight;
    }
  }

  /**
   * Verify Session Authentication on Load
   */
  async function verifySession() {
    try {
      const res = await window.AdminAPI.checkSession();
      if (!res.ok || !res.data || !res.data.authenticated) {
        if (res.isNetworkError) {
          // Backend is disconnected
          if (backendNotice) {
            backendNotice.style.display = "flex";
            backendNotice.innerHTML = `
              <span>⚠️ <strong>Backend Disconnected:</strong> A separate HTTPS backend service (AWS SSM / API Gateway / systemd daemon) is required to execute server management actions. The frontend is currently operating in disconnected mode.</span>
            `;
          }
        } else {
          // Explicit 401/403 unauthorized
          window.location.replace("login.html");
        }
      }
    } catch (_) {
      // Offline fallback
    }
  }

  /**
   * Fetch Dashboard Metrics & Live Status
   */
  async function refreshMetrics() {
    if (refreshDashBtn) {
      refreshDashBtn.disabled = true;
      refreshDashBtn.textContent = "↻ Updating...";
    }

    try {
      const res = await window.AdminAPI.getStatus();
      if (res.ok && res.data) {
        const d = res.data;
        updateStatusBadge(d.online ? "online" : "offline");
        uptimeVal.textContent = d.uptime || "—";
        mapVal.textContent = d.map || "Unknown";
        waveVal.textContent = d.wave !== undefined ? d.wave : "—";
        playersVal.textContent = `${d.players || 0} / ${d.maxPlayers || 16}`;
        if (cpuVal) cpuVal.textContent = d.cpu !== undefined ? `${d.cpu}%` : "—";
        if (ramVal) ramVal.textContent = d.ram !== undefined ? `${d.ram} MB` : "—";
      } else {
        // Unknown or offline backend
        updateStatusBadge("unknown");
        uptimeVal.textContent = "—";
        mapVal.textContent = "Unknown";
        waveVal.textContent = "—";
        playersVal.textContent = "— / 16";
        if (cpuVal) cpuVal.textContent = "—";
        if (ramVal) ramVal.textContent = "—";
      }
    } catch (err) {
      updateStatusBadge("unknown");
    } finally {
      if (refreshDashBtn) {
        refreshDashBtn.disabled = false;
        refreshDashBtn.textContent = "↻ Refresh Overview";
      }
    }
  }

  function updateStatusBadge(state) {
    if (!statusBadge || !statusText) return;
    statusBadge.classList.remove("status-online", "status-offline", "status-unknown");
    if (state === "online") {
      statusBadge.classList.add("status-online");
      statusText.textContent = "Online";
    } else if (state === "offline") {
      statusBadge.classList.add("status-offline");
      statusText.textContent = "Offline";
    } else {
      statusBadge.classList.add("status-unknown");
      statusText.textContent = "Unknown";
    }
  }

  if (refreshDashBtn) refreshDashBtn.addEventListener("click", refreshMetrics);

  /**
   * Server Power Controls (Start, Stop, Restart)
   */
  if (btnStart) {
    btnStart.addEventListener("click", () => {
      askConfirmation(
        "Start Mindustry Server",
        "This will invoke the AWS EC2 management daemon to start the Mindustry server process (server-release.jar). Proceed?",
        "Start Server",
        "btn-primary",
        async () => {
          showToast("Sending start command to backend...");
          appendConsoleLine("Executing action: start server", "cmd");
          const res = await window.AdminAPI.controlServer("start");
          if (res.ok) {
            showToast("Server startup sequence initiated.");
            appendConsoleLine("Server startup command dispatched successfully.", "info");
            refreshMetrics();
          } else {
            showToast(res.error || "Failed to start server.");
            appendConsoleLine(`Error starting server: ${res.error}`, "error");
          }
        }
      );
    });
  }

  if (btnStop) {
    btnStop.addEventListener("click", () => {
      askConfirmation(
        "Stop Mindustry Server",
        "WARNING: Stopping the server will disconnect all active players and halt the game simulation. Are you sure you want to stop the server?",
        "Stop Server",
        "btn-danger",
        async () => {
          showToast("Sending stop command to backend...");
          appendConsoleLine("Executing action: stop server", "cmd");
          const res = await window.AdminAPI.controlServer("stop");
          if (res.ok) {
            showToast("Server stopped successfully.");
            appendConsoleLine("Server stopped.", "warn");
            refreshMetrics();
          } else {
            showToast(res.error || "Failed to stop server.");
            appendConsoleLine(`Error stopping server: ${res.error}`, "error");
          }
        }
      );
    });
  }

  if (btnRestart) {
    btnRestart.addEventListener("click", () => {
      askConfirmation(
        "Restart Mindustry Server",
        "This will trigger a safe save of the current world map, reboot the Mindustry service, and reinitialize port 6567. Proceed?",
        "Restart Server",
        "btn-restart",
        async () => {
          showToast("Sending restart command to backend...");
          appendConsoleLine("Executing action: restart server", "cmd");
          const res = await window.AdminAPI.controlServer("restart");
          if (res.ok) {
            showToast("Server restart sequence begun.");
            appendConsoleLine("Server restarting...", "info");
            setTimeout(refreshMetrics, 3000);
          } else {
            showToast(res.error || "Failed to restart server.");
            appendConsoleLine(`Error restarting server: ${res.error}`, "error");
          }
        }
      );
    });
  }

  /**
   * Server Configuration Form
   */
  if (configForm) {
    configForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const payload = {
        name: inputServerName ? inputServerName.value.trim() : "Zootopia",
        playerLimit: inputPlayerLimit ? parseInt(inputPlayerLimit.value, 10) : 16,
        motd: inputMotd ? inputMotd.value.trim() : "",
        map: inputMap ? inputMap.value.trim() : ""
      };

      if (!payload.name) {
        showToast("Server name cannot be empty.");
        return;
      }
      if (isNaN(payload.playerLimit) || payload.playerLimit < 1 || payload.playerLimit > 64) {
        showToast("Player limit must be between 1 and 64.");
        return;
      }

      showToast("Saving server configuration...");
      const res = await window.AdminAPI.updateConfig(payload);
      if (res.ok) {
        showToast("Configuration successfully updated!");
        appendConsoleLine(`Server configuration updated: Limit=${payload.playerLimit}, Name="${payload.name}"`, "info");
      } else {
        showToast(res.error || "Configuration update failed.");
        appendConsoleLine(`Configuration update failed: ${res.error}`, "error");
      }
    });
  }

  /**
   * Player Management (Kick, Ban, Unban)
   */
  async function loadPlayers() {
    if (!playerTableBody) return;
    try {
      const res = await window.AdminAPI.getPlayers();
      if (res.ok && Array.isArray(res.data) && res.data.length > 0) {
        playerTableBody.innerHTML = res.data.map(p => `
          <tr>
            <td><strong>${escapeHtml(p.name)}</strong></td>
            <td><code>${escapeHtml(p.id || p.ip || "—")}</code></td>
            <td>${p.ping ? p.ping + " ms" : "—"}</td>
            <td>${escapeHtml(p.duration || "Just joined")}</td>
            <td>
              <div class="action-btns">
                <button type="button" class="btn-sm btn-kick" data-id="${escapeHtml(p.id)}" data-name="${escapeHtml(p.name)}">Kick</button>
                <button type="button" class="btn-sm btn-ban" data-id="${escapeHtml(p.id)}" data-name="${escapeHtml(p.name)}">Ban</button>
              </div>
            </td>
          </tr>
        `).join("");

        wirePlayerButtons();
      } else {
        playerTableBody.innerHTML = `
          <tr>
            <td colspan="5" style="text-align:center;color:var(--muted);padding:30px;">
              No players currently connected or status service is offline.
            </td>
          </tr>
        `;
      }
    } catch (_) {
      playerTableBody.innerHTML = `
        <tr>
          <td colspan="5" style="text-align:center;color:var(--muted);padding:30px;">
            Player data unavailable (Backend service offline).
          </td>
        </tr>
      `;
    }
  }

  function wirePlayerButtons() {
    document.querySelectorAll(".btn-kick").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.id;
        const name = btn.dataset.name;
        askConfirmation(`Kick ${name}?`, `Are you sure you want to disconnect ${name} from Zootopia?`, "Kick Player", "btn-restart", async () => {
          showToast(`Kicking ${name}...`);
          const res = await window.AdminAPI.playerAction("kick", id, "Kicked by administrator");
          if (res.ok) {
            showToast(`${name} was kicked.`);
            appendConsoleLine(`Player kicked: ${name} (${id})`, "warn");
            loadPlayers();
          } else {
            showToast(res.error || `Failed to kick ${name}.`);
          }
        });
      });
    });

    document.querySelectorAll(".btn-ban").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.id;
        const name = btn.dataset.name;
        askConfirmation(`Ban ${name}?`, `Are you sure you want to permanently blacklist ${name} (${id}) from joining Zootopia?`, "Ban Player", "btn-danger", async () => {
          showToast(`Banning ${name}...`);
          const res = await window.AdminAPI.playerAction("ban", id, "Griefing / Rules Violation");
          if (res.ok) {
            showToast(`${name} was banned.`);
            appendConsoleLine(`Player banned: ${name} (${id})`, "error");
            loadPlayers();
          } else {
            showToast(res.error || `Failed to ban ${name}.`);
          }
        });
      });
    });
  }

  if (btnUnban && inputUnbanId) {
    btnUnban.addEventListener("click", async () => {
      const targetId = inputUnbanId.value.trim();
      if (!targetId) {
        showToast("Enter a Player IP or ID to unban.");
        return;
      }
      showToast(`Unbanning ${targetId}...`);
      const res = await window.AdminAPI.playerAction("unban", targetId);
      if (res.ok) {
        showToast(`Successfully unbanned ${targetId}.`);
        appendConsoleLine(`Unbanned ID: ${targetId}`, "info");
        inputUnbanId.value = "";
      } else {
        showToast(res.error || "Failed to unban player.");
      }
    });
  }

  /**
   * Console Execution & Allowlist Validation
   */
  async function submitConsoleCommand() {
    if (!consoleInput) return;
    const cmd = consoleInput.value.trim();
    if (!cmd) return;

    appendConsoleLine(`> ${cmd}`, "cmd");
    consoleInput.value = "";

    const res = await window.AdminAPI.sendConsoleCommand(cmd);
    if (res.ok) {
      const output = (res.data && (res.data.output || res.data.message)) || "Command executed successfully.";
      appendConsoleLine(output, "info");
    } else {
      appendConsoleLine(`[Error] ${res.error}`, "error");
    }
  }

  if (consoleSubmitBtn) consoleSubmitBtn.addEventListener("click", submitConsoleCommand);
  if (consoleInput) {
    consoleInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        submitConsoleCommand();
      }
    });
  }

  if (clearConsoleBtn && consoleOutput) {
    clearConsoleBtn.addEventListener("click", () => {
      consoleOutput.innerHTML = "";
      appendConsoleLine("Console cleared.", "system");
    });
  }

  // Safe Command Chips
  commandChips.forEach(chip => {
    chip.addEventListener("click", () => {
      const sample = chip.dataset.cmd;
      if (consoleInput) {
        consoleInput.value = sample;
        consoleInput.focus();
      }
    });
  });

  /**
   * Sign Out
   */
  if (signOutBtn) {
    signOutBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        await window.AdminAPI.logout();
      } catch (_) {}
      window.location.replace("login.html");
    });
  }

  /**
   * Theme Switcher
   */
  if (themeBtn) {
    themeBtn.addEventListener("click", () => {
      document.body.classList.toggle("dark");
      localStorage.setItem("theme", document.body.classList.contains("dark") ? "dark" : "light");
    });
  }
  if (localStorage.getItem("theme") === "dark") {
    document.body.classList.add("dark");
  }

  function escapeHtml(str) {
    return String(str || "").replace(/[&<>"']/g, m => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[m]));
  }

  // Initial runs
  verifySession();
  refreshMetrics();
  loadPlayers();
  appendConsoleLine("Mindustry Administration Console initialized.", "system");
  appendConsoleLine("Safe command allowlist active. Shell execution is strictly disabled.", "system");
})();
